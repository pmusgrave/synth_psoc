/*******************************************************************************
* File Name: square_wave_output.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_square_wave_output_H) /* Pins square_wave_output_H */
#define CY_PINS_square_wave_output_H

#include "cytypes.h"
#include "cyfitter.h"
#include "square_wave_output_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} square_wave_output_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   square_wave_output_Read(void);
void    square_wave_output_Write(uint8 value);
uint8   square_wave_output_ReadDataReg(void);
#if defined(square_wave_output__PC) || (CY_PSOC4_4200L) 
    void    square_wave_output_SetDriveMode(uint8 mode);
#endif
void    square_wave_output_SetInterruptMode(uint16 position, uint16 mode);
uint8   square_wave_output_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void square_wave_output_Sleep(void); 
void square_wave_output_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(square_wave_output__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define square_wave_output_DRIVE_MODE_BITS        (3)
    #define square_wave_output_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - square_wave_output_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the square_wave_output_SetDriveMode() function.
         *  @{
         */
        #define square_wave_output_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define square_wave_output_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define square_wave_output_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define square_wave_output_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define square_wave_output_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define square_wave_output_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define square_wave_output_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define square_wave_output_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define square_wave_output_MASK               square_wave_output__MASK
#define square_wave_output_SHIFT              square_wave_output__SHIFT
#define square_wave_output_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in square_wave_output_SetInterruptMode() function.
     *  @{
     */
        #define square_wave_output_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define square_wave_output_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define square_wave_output_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define square_wave_output_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(square_wave_output__SIO)
    #define square_wave_output_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(square_wave_output__PC) && (CY_PSOC4_4200L)
    #define square_wave_output_USBIO_ENABLE               ((uint32)0x80000000u)
    #define square_wave_output_USBIO_DISABLE              ((uint32)(~square_wave_output_USBIO_ENABLE))
    #define square_wave_output_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define square_wave_output_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define square_wave_output_USBIO_ENTER_SLEEP          ((uint32)((1u << square_wave_output_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << square_wave_output_USBIO_SUSPEND_DEL_SHIFT)))
    #define square_wave_output_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << square_wave_output_USBIO_SUSPEND_SHIFT)))
    #define square_wave_output_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << square_wave_output_USBIO_SUSPEND_DEL_SHIFT)))
    #define square_wave_output_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(square_wave_output__PC)
    /* Port Configuration */
    #define square_wave_output_PC                 (* (reg32 *) square_wave_output__PC)
#endif
/* Pin State */
#define square_wave_output_PS                     (* (reg32 *) square_wave_output__PS)
/* Data Register */
#define square_wave_output_DR                     (* (reg32 *) square_wave_output__DR)
/* Input Buffer Disable Override */
#define square_wave_output_INP_DIS                (* (reg32 *) square_wave_output__PC2)

/* Interrupt configuration Registers */
#define square_wave_output_INTCFG                 (* (reg32 *) square_wave_output__INTCFG)
#define square_wave_output_INTSTAT                (* (reg32 *) square_wave_output__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define square_wave_output_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(square_wave_output__SIO)
    #define square_wave_output_SIO_REG            (* (reg32 *) square_wave_output__SIO)
#endif /* (square_wave_output__SIO_CFG) */

/* USBIO registers */
#if !defined(square_wave_output__PC) && (CY_PSOC4_4200L)
    #define square_wave_output_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define square_wave_output_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define square_wave_output_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define square_wave_output_DRIVE_MODE_SHIFT       (0x00u)
#define square_wave_output_DRIVE_MODE_MASK        (0x07u << square_wave_output_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins square_wave_output_H */


/* [] END OF FILE */
