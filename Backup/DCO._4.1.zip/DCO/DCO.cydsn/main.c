#include "project.h"

#define ADC_CHANNEL 0u

int convert_voltage_to_frequency(int voltage);
int convert_frequency_to_time_delay(int frequency);
void toggle_square_wave();

CY_ISR(Timer1_Handler)
{
    toggle_square_wave();
    
    Timer1_ClearInterrupt(Timer1_INTR_MASK_CC_MATCH);
}
int main(void)
{
    int16 ADC_result = 0u;
    float ADC_converted_result = 0u;
    int16 frequency = 0u;
    int16 time_delay = 0u;
    
    Timer1_Start();
    IDAC_Start();
    Comp_1_Start();
    Pot_H_Write(1);
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    isr_Timer1_StartEx(Timer1_Handler);
    
    /* ADC config */
    ADC_SAR_Seq_1_Start();
    ADC_SAR_Seq_1_StartConvert();
    
    for(;;)
    {
        ADC_SAR_Seq_1_IsEndConversion(ADC_SAR_Seq_1_WAIT_FOR_RESULT);
        ADC_result = ADC_SAR_Seq_1_GetResult16(ADC_CHANNEL);
        ADC_converted_result = ADC_SAR_Seq_1_CountsTo_mVolts(ADC_CHANNEL, ADC_result);
        
        /*
        if ( ADC_converted_result >= 1000 ) {
            ADC_converted_result = 1000;
        }
        else if (ADC_converted_result <= 0) {
            ADC_converted_result = 0;
        }
        */
        
        Timer1_WritePeriod(ADC_result);
        
        //frequency = convert_voltage_to_frequency(ADC_converted_result);
        //time_delay = convert_frequency_to_time_delay(frequency);
        //CyDelay(time_delay);
        //toggle_square_wave();
        CyDelayUs(1);
    }
   
}

int convert_voltage_to_frequency(int voltage) {
    return voltage;
}

int convert_frequency_to_time_delay(int frequency){
    return ((1.0/(frequency+1)) * 1000);
}

void toggle_square_wave(){
    square_wave_output_Write(~square_wave_output_Read());
}

/* [] END OF FILE */
